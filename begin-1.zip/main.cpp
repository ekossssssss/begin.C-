//Begin1◦ Дана сторона квадрата a. Найти его периметр P = 4·a.

#include <iostream>

using namespace std;

int main()
{
    float a;
    scanf("%f", &a);
    float P=4*a;
    printf("P=%.2f", P);

    return 0;
}
