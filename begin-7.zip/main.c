//Костюк Екатерина 22ис-21 Найти длину окружности L и площадь круга S заданного радиуса R:L = 2·π·R, S = π·R2/

#include <stdio.h>
float main()
{
    float r;
    scanf("%f", &r);
    float p = 3.14;
    float dlina = 2 * (p * r);
    float s = 3.14 * (r * r);
    printf("%.2f%.2f\n", dlina, s );
    return 0;
}
