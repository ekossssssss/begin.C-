//Даны два неотрицательных числа a и b. Найти их среднее геометрическое, то есть квадратный корень из их произведения: √a·b//

#include <math.h>

float main()

{   
    float a, b;
    scanf("%f%f", &a, &b);
    float sr = sqrt(a * b);
    printf("%f\n", sr);
    return 0;

    
}
