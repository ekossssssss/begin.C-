//Begin  Дана сторона квадрата a. Найти его площадь S = a^2 Костюк Катя 22ис-21



#include <stdio.h>

int main()
{ 
    float a;
    scanf("%f", &a);
    float p = a * a;
    printf("p=%.2f", p);
    return 0;
}