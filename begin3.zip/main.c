//Даны стороны прямоугольника a и b. Найти его площадь S = a·b и периметр P = 2·(a + b).

#include <stdio.h>

int main ()
{
    int a, b;
    scanf("%d%d", &a, &b);
    int ploshad;
    ploshad = a * b;
    printf("%d\n", ploshad);
    int perimetr;
    perimetr = 2 * (a + b);
    printf("%d\n", perimetr);
    return 0;
}