//Дан диаметр окружности d. Найти ее длину L = π·d. В качестве значения π использовать 3.14.

#include <stdio.h>
float main()
{
    float d;
    scanf("%f", &d);
    float dlina;
    float dlina = 3.14 * d;
    printf("%f\n", dlina);
    return 0;
}