//Даны длины ребер a, b, c прямоугольного параллелепипеда. Найти его объем V = a·b·c и площадь поверхности
//S = 2·(a·b + b·c + a·c).//

#include <stdio.h>

int main ()
{
    int a, b, c;
    scanf("%d%d%d", &a, &b, &c);
    int obj;
    obj = a * b * c;
    printf("%d\n", obj);
    int ploshad;
    ploshad = 2 * (a * b + b * c + a * c);
    printf("%d\n", ploshad);
    return 0;
}